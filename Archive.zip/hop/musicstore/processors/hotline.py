def hotline(request):
    hotline_info = {'name':'Dustin','phone':'123-456-789'}
    return {'HOTLINE': hotline_info}
