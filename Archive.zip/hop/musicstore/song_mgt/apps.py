from django.apps import AppConfig


class ProductMgtConfig(AppConfig):
    name = 'song_mgt'
